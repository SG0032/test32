<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Produit;

class StoreController extends AbstractController
{
    /**
     * @Route("/store", name="store")
     */
    public function index(): Response
    {
        $repo = $this->getDoctrine()->getRepository(Produit::class);

        $produits = $repo->findAll();
        return $this->render('store/index.html.twig', [
            'controller_name' => 'StoreController',
            'produits' => $produits
        ]);
    }

    /**
     * @Route("/", name="home")
     */

    public function home(){
        return $this->render('store/home.html.twig');
    }
    /**
     * @Route("/store/{id}", name="store_show")
     */
    public function show($id){
        
        $repo = $this->getDoctrine()->getRepository(Produit::class);

        $produit = $repo->find($id);

        return $this->render('store/show.html.twig', [
            'produit' => $produit
        ]);
    }

    

    
}
