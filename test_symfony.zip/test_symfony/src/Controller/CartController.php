<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Controller\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use App\Repository\ProduitRepository;
use App\Entity\Produit;

class CartController extends AbstractController
{
    /**
     * @Route("/panier", name="cart")
     */
    public function index(SessionInterface $session , ProduitRepository $productRepository): Response
    {
        $panier = $session->get('panier', []);

        $panierWithData = [];
        foreach($panier as $id => $quantity){
            $panierWithData = [
                'produit'=> $productRepository->find($id),
                'quantity' =>$quantity
            ];
        }
    
        return $this->render('cart/index.html.twig', [
            'items'=> $panierWithData
        ]);
    }

    /**
     * @Route("/panier/add/{id}", name ="cart_add")
     */
    public function add($id, SessionInterface $session){
     
        $panier = $session->get('panier', []);
        
        if(!empty($panier[$id])){
            $panier[$id]++;
        }else{
            $panier[$id] = 1;
        }
        
        $session->set('panier', $panier);
        dd($session->get('panier'));

    }
}

