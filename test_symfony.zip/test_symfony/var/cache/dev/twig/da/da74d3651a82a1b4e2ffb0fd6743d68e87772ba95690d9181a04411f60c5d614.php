<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* store/show.html.twig */
class __TwigTemplate_5da5f008d35b0965076844e7d992f4152dce81ad87aeb5434d87c9a547257c85 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "store/show.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "store/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <article>
    
        <h2>";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 6, $this->source); })()), "nomProduit", [], "any", false, false, false, 6), "html", null, true);
        echo "</h2>
        <div class=\"metadata\">Ajouter le ";
        // line 7
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 7, $this->source); })()), "createdAt", [], "any", false, false, false, 7), "d/m/Y"), "html", null, true);
        echo "</div>
        <div class=\"content\">
            <img src=\"";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 9, $this->source); })()), "image", [], "any", false, false, false, 9), "html", null, true);
        echo "\" alt=\"\"> 
            
                     <p>
                        Reference produit : ";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 12, $this->source); })()), "reference", [], "any", false, false, false, 12), "html", null, true);
        echo "
                     </p>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, cupiditate?
                        Quae minus sunt repellendus corrupti nulla fugiaoloremque corporis totam!
                    </p>
                    <p>
                        Prix de produit : ";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 19, $this->source); })()), "prix", [], "any", false, false, false, 19), "html", null, true);
        echo "
                    </p>
                    <p>
                        Itaque facere aspernatur optio! Mollitia laudantium fugiat quis expedita, 
                        veritatis similique corporis sunt odio, voluptatum quibusdam praesentium nobis itaque iste. 
                        Voluptate soluta quis, asperiores nulla iusto ut sapiente reiciendis aspernatur? 
                        Officia aperiam obcaecati odio beatae rem, recusandae libero sapiente voluptatem.
                        Doloribus distinctio qui itaque harum perferendis consequuntur ullam voluptate voluptatibus.
                     </p>


        </div>
    </article>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "store/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 19,  78 => 12,  72 => 9,  67 => 7,  63 => 6,  59 => 4,  52 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig'%}

{% block body %}
    <article>
    
        <h2>{{produit.nomProduit}}</h2>
        <div class=\"metadata\">Ajouter le {{produit.createdAt | date('d/m/Y')}}</div>
        <div class=\"content\">
            <img src=\"{{produit.image}}\" alt=\"\"> 
            
                     <p>
                        Reference produit : {{produit.reference}}
                     </p>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, cupiditate?
                        Quae minus sunt repellendus corrupti nulla fugiaoloremque corporis totam!
                    </p>
                    <p>
                        Prix de produit : {{produit.prix}}
                    </p>
                    <p>
                        Itaque facere aspernatur optio! Mollitia laudantium fugiat quis expedita, 
                        veritatis similique corporis sunt odio, voluptatum quibusdam praesentium nobis itaque iste. 
                        Voluptate soluta quis, asperiores nulla iusto ut sapiente reiciendis aspernatur? 
                        Officia aperiam obcaecati odio beatae rem, recusandae libero sapiente voluptatem.
                        Doloribus distinctio qui itaque harum perferendis consequuntur ullam voluptate voluptatibus.
                     </p>


        </div>
    </article>

{% endblock %}", "store/show.html.twig", "C:\\wamp64\\www\\test_symfony\\templates\\store\\show.html.twig");
    }
}
